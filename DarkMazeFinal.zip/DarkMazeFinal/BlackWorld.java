import greenfoot.*;
import java.util.ArrayDeque;
import java.util.Deque;
import java.awt.Rectangle;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class BlackWorld extends World
{
    private int n,banderaNivel;
    private Timer timer = new Timer();
    private Label label = new Label();
    private Phantom phantom;
    private YellowCircle yc = new YellowCircle(70);
    private List<Integer> numbers = new ArrayList<>();
    Corazon c1,c2,c3;
    private Door door1;
    private Door door2;
    private Door door3;
    private int numR1, numR2, numR3;
    private Fed fedIn;
    private boolean time = false;
    itemTimeXtra itemTime;
    CircleCollider collider = new CircleCollider(15);
    public BlackWorld(int n, int banderaNivel)
    {  
        super(1280, 720, 1);
        this.n=n;
        this.banderaNivel=banderaNivel;
        numbers= generateRandomNumbers();
        numR1= numbers.get(0);
        numR2= numbers.get(1);
        numR3= numbers.get(2);
        setBackground("fondoNegro.jpg"); 
         if(banderaNivel==1){
            door1 = new Door(this,numR1,n,banderaNivel);
            door3 = new Door(this,numR3,n,banderaNivel);
        }else{
            door1 = new Door(this,numR1,n,banderaNivel);
            door2 = new Door(this, numR2,n,banderaNivel);
            door3 = new Door(this,numR3,n,banderaNivel);
        }
      
        itemTime = new itemTimeXtra(timer,collider);
        
    }
   
    public void act()
    {
       if(time == false){
            fedIn = new Fed();
            addObject(fedIn ,getWidth()/2 , getHeight()/2);
            fedIn.fedInAnim();
            removeObject(fedIn);
            if(banderaNivel==1){
            addObject(door1, getWidth()-900 , getHeight()-305);
            addObject(door3, getWidth()-362 , getHeight()-305);
            }else{
            addObject(door1, getWidth()-1065 , getHeight()-305);
            addObject(door2, getWidth()-640 , getHeight()-305);
            addObject(door3, getWidth()-212 , getHeight()-305);
             }
             
            if(n==2){
            c1=new Corazon();
            c2=new Corazon();
            addObject(c1, 275 , 70 );
            addObject(c2, 350 , 70 );
        }else if(n==1){
            c1=new Corazon();
            addObject(c1, 275 , 70 );
        }else if(n==3){
            c1=new Corazon();
            c2=new Corazon();
            c3=new Corazon(); 
            addObject(c3, 425 , 70 ); 
            addObject(c2, 350 , 70 );
            addObject(c1, 275 , 70 );
        }
            time=true;
        }
        /* if(timer.getTime()<0)
        removeObject(itemTime);*/
         
    }
   public List<Integer> generateRandomNumbers() {
    for (int i = 0; i < 3; i++) {
        int number;
        do {
            number = Greenfoot.getRandomNumber(3) + 1;
        } while (numbers.contains(number));
        numbers.add(number);
    }

    return numbers;
}
    public int randomX(){
        Random random = new Random();
        int numeroAleatorio = random.nextInt(1180) + 100;
        return numeroAleatorio;
    }
    public int randomY(){
        Random random = new Random();
        int numeroAleatorio = random.nextInt(620) + 50 ;
        return numeroAleatorio;
    }
    public void apareceFantasma() {
        phantom = new Phantom(label, timer,n,banderaNivel);
        addObject(phantom, getWidth() / 2, getHeight() / 2 + 50);
        addObject(timer, getWidth()-500, getHeight() / 10);
        addObject(label, getWidth()-200, getHeight() / 10);
        if(banderaNivel==3)
        addObject(itemTime,  randomX(),  randomY());
        addObject(yc, getWidth()/2 , getHeight()/2 );
        addObject(collider, getWidth() / 2, getHeight() / 2);
        removeObject(door1);
        removeObject(door2);
        removeObject(door3);
       
    }
    
    public void desapareceFantasma() {
         if (label.act2() == 0) {
        removeObject(phantom);
        }
    }
}