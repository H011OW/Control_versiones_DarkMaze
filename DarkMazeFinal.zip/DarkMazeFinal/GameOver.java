import greenfoot.GreenfootSound;
import greenfoot.*; 
public class GameOver extends BaseWorld
{
    private GreenfootSound amb;
    
    public GameOver()
    {    
        super(23, "gOver", 100, 2);
        amb = new GreenfootSound("sounds/gameOver.mp3");
        amb.play();
    }
}