import greenfoot.GreenfootSound;
import greenfoot.*; 

public class Inicio extends BaseWorld
{
    private GreenfootSound amb;
    
    public Inicio()
    {    
        super(22, "inicio", 1, 12);
        amb = new GreenfootSound("sounds/openDoor2.mp3");
    }

    @Override
    public void checkKeyPressBck()
    {   
        if (Greenfoot.isKeyDown("space")){
            start = true;
            amb.play();
        }
        if (start == true)
        {
            super.checkKeyPressBck();
            z++;
            if(z>20){
                amb.stop();
                Greenfoot.setWorld(new Corredor(3, 1, "back", 15,22));
            }
        }
    }
}